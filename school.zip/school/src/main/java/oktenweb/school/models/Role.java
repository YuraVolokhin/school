package oktenweb.school.models;

public enum Role {
    ROLE_STUDENT,
    ROLE_ADMIN,
    ROLE_TEACHER,
    ROLE_PARENT,
    ROLE_CLASSTHEACHER,
    ROLE_DEPUTI    //ЗАУЧ

}
